function yesClick() {
  document.getElementById("card").innerHTML = `
    <h1>YEAY 🥹🤍</h1>
    <p>Makasih ya udah mau.</p>
    <p>Aku janji bakal jaga perasaan kamu sebaik mungkin 🌷</p>
  `;
}

function moveNo() {
  const btn = document.getElementById("noBtn");
  const x = Math.random() * 200 - 100;
  const y = Math.random() * 200 - 100;
  btn.style.transform = `translate(${x}px, ${y}px)`;
}